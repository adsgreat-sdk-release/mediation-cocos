"use strict";
cc._RF.push(module, '43c9fz9XvNHe6MRRutnn7VN', 'RewardedVideo');
// Script/RewardedVideo.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var NBMediation = require('NBMediation');

cc.Class({
  "extends": cc.Component,
  properties: {
    showRVBtn: {
      "default": null,
      type: cc.Button
    },
    showIntersitialBtn: {
      "default": null,
      type: cc.Button
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    //setup id here
    this.appid = "kXDlKvOwFYf0inXBd65Pzo0vpF2utBim";
    this.bannerID = "259"; //setup button click event

    this.showRVBtn.node.on('click', this.showRV, this);
    this.showIntersitialBtn.node.on('click', this.showInterstitial, this); //init mediation 

    this.nbsdk = new NBMediation();
    this.nbsdk.init(this.appid); //load banner 

    this.nbsdk.loadBanner(this.bannerID);

    this.showBannerCallback = function () {
      if (this.nbsdk.isBannerReady(this.bannerID)) {
        this.unschedule(this.showBannerCallback);
        this.nbsdk.showBanner(this.bannerID);
      } else {
        console.log("banner isn't ready");
      }
    };

    this.schedule(this.showBannerCallback, 0.5);
  },
  showInterstitial: function showInterstitial(button) {
    console.log("showInterstitial"); //load interstitial

    if (this.nbsdk.isInterstitialReady()) {
      this.nbsdk.showInterstitial();
    } else {
      console.log("interstitial isn't ready");
    }
  },
  showRV: function showRV(button) {
    console.log("showRV"); //load rewarded video

    if (this.nbsdk.isRewardedVideoReady()) {
      this.nbsdk.showRewardedVideo();
    } else {
      console.log("rv isn't ready");
    }
  },
  onDestroy: function onDestroy() {
    this.nbsdk.hideBanner(this.bannerID);
  } // update (dt) {},

});

cc._RF.pop();