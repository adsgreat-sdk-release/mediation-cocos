"use strict";
cc._RF.push(module, '41aaa10R/tFqbtaiEZQaOxN', 'NBMediation');
// NBMediation/NBMediation.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var NBMediation = cc.Class({
  "extends": cc.Component,
  properties: {// foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  init: function init(appid) {
    console.log("appid:" + appid);
    jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "initNBMediation", "(Ljava/lang/String;)V", appid);
  },
  isRewardedVideoReady: function isRewardedVideoReady() {
    return jsb.reflection.callStaticMethod("com/nbmediation/sdk/api/unity/NmSdk", "isRewardedVideoReady", "()Z");
  },
  showRewardedVideo: function showRewardedVideo() {
    jsb.reflection.callStaticMethod("com/nbmediation/sdk/api/unity/NmSdk", "showRewardedVideo", "()V");
  },
  isInterstitialReady: function isInterstitialReady() {
    return jsb.reflection.callStaticMethod("com/nbmediation/sdk/api/unity/NmSdk", "isInterstitialReady", "()Z");
  },
  showInterstitial: function showInterstitial() {
    jsb.reflection.callStaticMethod("com/nbmediation/sdk/api/unity/NmSdk", "showInterstitial", "()V");
  },
  loadBanner: function loadBanner(slotid) {
    jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "loadBanner", "(Ljava/lang/String;)V", slotid);
  },
  showBanner: function showBanner(slotid) {
    jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "showBanner", "(Ljava/lang/String;)V", slotid);
  },
  hideBanner: function hideBanner(slotid) {
    jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "hideBanner", "(Ljava/lang/String;)V", slotid);
  },
  isBannerReady: function isBannerReady(slotid) {
    return jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "isBannerReady", "(Ljava/lang/String;)Z", slotid);
  } // update (dt) {},

});
module.exports = NBMediation;

cc._RF.pop();