
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/NBMediation/NBMediation');
require('./assets/Script/RewardedVideo');
require('./assets/migration/use_v2.1-2.2.1_cc.Toggle_event');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/NBMediation/NBMediation.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '41aaa10R/tFqbtaiEZQaOxN', 'NBMediation');
// NBMediation/NBMediation.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var NBMediation = cc.Class({
  "extends": cc.Component,
  properties: {// foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  init: function init(appid) {
    console.log("appid:" + appid);
    jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "initNBMediation", "(Ljava/lang/String;)V", appid);
  },
  isRewardedVideoReady: function isRewardedVideoReady() {
    return jsb.reflection.callStaticMethod("com/nbmediation/sdk/api/unity/NmSdk", "isRewardedVideoReady", "()Z");
  },
  showRewardedVideo: function showRewardedVideo() {
    jsb.reflection.callStaticMethod("com/nbmediation/sdk/api/unity/NmSdk", "showRewardedVideo", "()V");
  },
  isInterstitialReady: function isInterstitialReady() {
    return jsb.reflection.callStaticMethod("com/nbmediation/sdk/api/unity/NmSdk", "isInterstitialReady", "()Z");
  },
  showInterstitial: function showInterstitial() {
    jsb.reflection.callStaticMethod("com/nbmediation/sdk/api/unity/NmSdk", "showInterstitial", "()V");
  },
  loadBanner: function loadBanner(slotid) {
    jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "loadBanner", "(Ljava/lang/String;)V", slotid);
  },
  showBanner: function showBanner(slotid) {
    jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "showBanner", "(Ljava/lang/String;)V", slotid);
  },
  hideBanner: function hideBanner(slotid) {
    jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "hideBanner", "(Ljava/lang/String;)V", slotid);
  },
  isBannerReady: function isBannerReady(slotid) {
    return jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "isBannerReady", "(Ljava/lang/String;)Z", slotid);
  } // update (dt) {},

});
module.exports = NBMediation;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9OQk1lZGlhdGlvbi9OQk1lZGlhdGlvbi5qcyJdLCJuYW1lcyI6WyJOQk1lZGlhdGlvbiIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwic3RhcnQiLCJpbml0IiwiYXBwaWQiLCJjb25zb2xlIiwibG9nIiwianNiIiwicmVmbGVjdGlvbiIsImNhbGxTdGF0aWNNZXRob2QiLCJpc1Jld2FyZGVkVmlkZW9SZWFkeSIsInNob3dSZXdhcmRlZFZpZGVvIiwiaXNJbnRlcnN0aXRpYWxSZWFkeSIsInNob3dJbnRlcnN0aXRpYWwiLCJsb2FkQmFubmVyIiwic2xvdGlkIiwic2hvd0Jhbm5lciIsImhpZGVCYW5uZXIiLCJpc0Jhbm5lclJlYWR5IiwibW9kdWxlIiwiZXhwb3J0cyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxJQUFJQSxXQUFXLEdBQUdDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ3ZCLGFBQVNELEVBQUUsQ0FBQ0UsU0FEVztBQUd2QkMsRUFBQUEsVUFBVSxFQUFFLENBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBZlEsR0FIVztBQXFCdkI7QUFFQTtBQUVBQyxFQUFBQSxLQXpCdUIsbUJBeUJkLENBR1IsQ0E1QnNCO0FBOEJ2QkMsRUFBQUEsSUE5QnVCLGdCQThCakJDLEtBOUJpQixFQThCVjtBQUNUQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxXQUFXRixLQUF2QjtBQUNBRyxJQUFBQSxHQUFHLENBQUNDLFVBQUosQ0FBZUMsZ0JBQWYsQ0FBZ0MscUNBQWhDLEVBQXVFLGlCQUF2RSxFQUEwRix1QkFBMUYsRUFBbUhMLEtBQW5IO0FBQ0gsR0FqQ3NCO0FBbUN2Qk0sRUFBQUEsb0JBbkN1QixrQ0FtQ0E7QUFDbkIsV0FBT0gsR0FBRyxDQUFDQyxVQUFKLENBQWVDLGdCQUFmLENBQWdDLHFDQUFoQyxFQUF1RSxzQkFBdkUsRUFBK0YsS0FBL0YsQ0FBUDtBQUNILEdBckNzQjtBQXVDdkJFLEVBQUFBLGlCQXZDdUIsK0JBdUNIO0FBQ2hCSixJQUFBQSxHQUFHLENBQUNDLFVBQUosQ0FBZUMsZ0JBQWYsQ0FBZ0MscUNBQWhDLEVBQXVFLG1CQUF2RSxFQUE0RixLQUE1RjtBQUNILEdBekNzQjtBQTJDdkJHLEVBQUFBLG1CQTNDdUIsaUNBMkNEO0FBQ2xCLFdBQU9MLEdBQUcsQ0FBQ0MsVUFBSixDQUFlQyxnQkFBZixDQUFnQyxxQ0FBaEMsRUFBdUUscUJBQXZFLEVBQThGLEtBQTlGLENBQVA7QUFDSCxHQTdDc0I7QUErQ3ZCSSxFQUFBQSxnQkEvQ3VCLDhCQStDSjtBQUNmTixJQUFBQSxHQUFHLENBQUNDLFVBQUosQ0FBZUMsZ0JBQWYsQ0FBZ0MscUNBQWhDLEVBQXVFLGtCQUF2RSxFQUEyRixLQUEzRjtBQUNILEdBakRzQjtBQW1EdkJLLEVBQUFBLFVBbkR1QixzQkFtRFpDLE1BbkRZLEVBbURMO0FBQ2RSLElBQUFBLEdBQUcsQ0FBQ0MsVUFBSixDQUFlQyxnQkFBZixDQUFnQyxxQ0FBaEMsRUFBdUUsWUFBdkUsRUFBcUYsdUJBQXJGLEVBQThHTSxNQUE5RztBQUNILEdBckRzQjtBQXVEdkJDLEVBQUFBLFVBdkR1QixzQkF1RFpELE1BdkRZLEVBdURMO0FBQ2RSLElBQUFBLEdBQUcsQ0FBQ0MsVUFBSixDQUFlQyxnQkFBZixDQUFnQyxxQ0FBaEMsRUFBdUUsWUFBdkUsRUFBcUYsdUJBQXJGLEVBQThHTSxNQUE5RztBQUNILEdBekRzQjtBQTJEdkJFLEVBQUFBLFVBM0R1QixzQkEyRFpGLE1BM0RZLEVBMkRMO0FBQ2RSLElBQUFBLEdBQUcsQ0FBQ0MsVUFBSixDQUFlQyxnQkFBZixDQUFnQyxxQ0FBaEMsRUFBdUUsWUFBdkUsRUFBcUYsdUJBQXJGLEVBQThHTSxNQUE5RztBQUNILEdBN0RzQjtBQStEdkJHLEVBQUFBLGFBL0R1Qix5QkErRFRILE1BL0RTLEVBK0RGO0FBQ2pCLFdBQU9SLEdBQUcsQ0FBQ0MsVUFBSixDQUFlQyxnQkFBZixDQUFnQyxxQ0FBaEMsRUFBdUUsZUFBdkUsRUFBd0YsdUJBQXhGLEVBQWlITSxNQUFqSCxDQUFQO0FBQ0gsR0FqRXNCLENBbUV2Qjs7QUFuRXVCLENBQVQsQ0FBbEI7QUFxRUFJLE1BQU0sQ0FBQ0MsT0FBUCxHQUFpQnZCLFdBQWpCIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcbi8vIExlYXJuIEF0dHJpYnV0ZTpcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxuXG52YXIgTkJNZWRpYXRpb24gPSBjYy5DbGFzcyh7XG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgIC8vIEFUVFJJQlVURVM6XG4gICAgICAgIC8vICAgICBkZWZhdWx0OiBudWxsLCAgICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgIHR5cGU6IGNjLlNwcml0ZUZyYW1lLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICAgc2VyaWFsaXphYmxlOiB0cnVlLCAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gYmFyOiB7XG4gICAgICAgIC8vICAgICBnZXQgKCkge1xuICAgICAgICAvLyAgICAgICAgIHJldHVybiB0aGlzLl9iYXI7XG4gICAgICAgIC8vICAgICB9LFxuICAgICAgICAvLyAgICAgc2V0ICh2YWx1ZSkge1xuICAgICAgICAvLyAgICAgICAgIHRoaXMuX2JhciA9IHZhbHVlO1xuICAgICAgICAvLyAgICAgfVxuICAgICAgICAvLyB9LFxuICAgIH0sXG5cbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcblxuICAgIC8vIG9uTG9hZCAoKSB7fSxcblxuICAgIHN0YXJ0ICgpIHtcblxuXG4gICAgfSxcblxuICAgIGluaXQgKGFwcGlkKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiYXBwaWQ6XCIgKyBhcHBpZCk7XG4gICAgICAgIGpzYi5yZWZsZWN0aW9uLmNhbGxTdGF0aWNNZXRob2QoXCJvcmcvY29jb3MyZHgvamF2YXNjcmlwdC9BcHBBY3Rpdml0eVwiLCBcImluaXROQk1lZGlhdGlvblwiLCBcIihMamF2YS9sYW5nL1N0cmluZzspVlwiLCBhcHBpZCk7XG4gICAgfSxcblxuICAgIGlzUmV3YXJkZWRWaWRlb1JlYWR5KCkge1xuICAgICAgICByZXR1cm4ganNiLnJlZmxlY3Rpb24uY2FsbFN0YXRpY01ldGhvZChcImNvbS9uYm1lZGlhdGlvbi9zZGsvYXBpL3VuaXR5L05tU2RrXCIsIFwiaXNSZXdhcmRlZFZpZGVvUmVhZHlcIiwgXCIoKVpcIik7XG4gICAgfSxcblxuICAgIHNob3dSZXdhcmRlZFZpZGVvKCkge1xuICAgICAgICBqc2IucmVmbGVjdGlvbi5jYWxsU3RhdGljTWV0aG9kKFwiY29tL25ibWVkaWF0aW9uL3Nkay9hcGkvdW5pdHkvTm1TZGtcIiwgXCJzaG93UmV3YXJkZWRWaWRlb1wiLCBcIigpVlwiKTtcbiAgICB9LFxuXG4gICAgaXNJbnRlcnN0aXRpYWxSZWFkeSgpIHtcbiAgICAgICAgcmV0dXJuIGpzYi5yZWZsZWN0aW9uLmNhbGxTdGF0aWNNZXRob2QoXCJjb20vbmJtZWRpYXRpb24vc2RrL2FwaS91bml0eS9ObVNka1wiLCBcImlzSW50ZXJzdGl0aWFsUmVhZHlcIiwgXCIoKVpcIik7XG4gICAgfSxcblxuICAgIHNob3dJbnRlcnN0aXRpYWwoKSB7XG4gICAgICAgIGpzYi5yZWZsZWN0aW9uLmNhbGxTdGF0aWNNZXRob2QoXCJjb20vbmJtZWRpYXRpb24vc2RrL2FwaS91bml0eS9ObVNka1wiLCBcInNob3dJbnRlcnN0aXRpYWxcIiwgXCIoKVZcIik7XG4gICAgfSxcblxuICAgIGxvYWRCYW5uZXIoc2xvdGlkKXtcbiAgICAgICAganNiLnJlZmxlY3Rpb24uY2FsbFN0YXRpY01ldGhvZChcIm9yZy9jb2NvczJkeC9qYXZhc2NyaXB0L0FwcEFjdGl2aXR5XCIsIFwibG9hZEJhbm5lclwiLCBcIihMamF2YS9sYW5nL1N0cmluZzspVlwiLCBzbG90aWQpO1xuICAgIH0sXG5cbiAgICBzaG93QmFubmVyKHNsb3RpZCl7XG4gICAgICAgIGpzYi5yZWZsZWN0aW9uLmNhbGxTdGF0aWNNZXRob2QoXCJvcmcvY29jb3MyZHgvamF2YXNjcmlwdC9BcHBBY3Rpdml0eVwiLCBcInNob3dCYW5uZXJcIiwgXCIoTGphdmEvbGFuZy9TdHJpbmc7KVZcIiwgc2xvdGlkKTtcbiAgICB9LFxuXG4gICAgaGlkZUJhbm5lcihzbG90aWQpe1xuICAgICAgICBqc2IucmVmbGVjdGlvbi5jYWxsU3RhdGljTWV0aG9kKFwib3JnL2NvY29zMmR4L2phdmFzY3JpcHQvQXBwQWN0aXZpdHlcIiwgXCJoaWRlQmFubmVyXCIsIFwiKExqYXZhL2xhbmcvU3RyaW5nOylWXCIsIHNsb3RpZCk7XG4gICAgfSxcblxuICAgIGlzQmFubmVyUmVhZHkoc2xvdGlkKXtcbiAgICAgICAgcmV0dXJuIGpzYi5yZWZsZWN0aW9uLmNhbGxTdGF0aWNNZXRob2QoXCJvcmcvY29jb3MyZHgvamF2YXNjcmlwdC9BcHBBY3Rpdml0eVwiLCBcImlzQmFubmVyUmVhZHlcIiwgXCIoTGphdmEvbGFuZy9TdHJpbmc7KVpcIiwgc2xvdGlkKTtcbiAgICB9LFxuXG4gICAgLy8gdXBkYXRlIChkdCkge30sXG59KTtcbm1vZHVsZS5leHBvcnRzID0gTkJNZWRpYXRpb247Il19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/RewardedVideo.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '43c9fz9XvNHe6MRRutnn7VN', 'RewardedVideo');
// Script/RewardedVideo.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var NBMediation = require('NBMediation');

cc.Class({
  "extends": cc.Component,
  properties: {
    showRVBtn: {
      "default": null,
      type: cc.Button
    },
    showIntersitialBtn: {
      "default": null,
      type: cc.Button
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    //setup id here
    this.appid = "kXDlKvOwFYf0inXBd65Pzo0vpF2utBim";
    this.bannerID = "259"; //setup button click event

    this.showRVBtn.node.on('click', this.showRV, this);
    this.showIntersitialBtn.node.on('click', this.showInterstitial, this); //init mediation 

    this.nbsdk = new NBMediation();
    this.nbsdk.init(this.appid); //load banner 

    this.nbsdk.loadBanner(this.bannerID);

    this.showBannerCallback = function () {
      if (this.nbsdk.isBannerReady(this.bannerID)) {
        this.unschedule(this.showBannerCallback);
        this.nbsdk.showBanner(this.bannerID);
      } else {
        console.log("banner isn't ready");
      }
    };

    this.schedule(this.showBannerCallback, 0.5);
  },
  showInterstitial: function showInterstitial(button) {
    console.log("showInterstitial"); //load interstitial

    if (this.nbsdk.isInterstitialReady()) {
      this.nbsdk.showInterstitial();
    } else {
      console.log("interstitial isn't ready");
    }
  },
  showRV: function showRV(button) {
    console.log("showRV"); //load rewarded video

    if (this.nbsdk.isRewardedVideoReady()) {
      this.nbsdk.showRewardedVideo();
    } else {
      console.log("rv isn't ready");
    }
  },
  onDestroy: function onDestroy() {
    this.nbsdk.hideBanner(this.bannerID);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHQvUmV3YXJkZWRWaWRlby5qcyJdLCJuYW1lcyI6WyJOQk1lZGlhdGlvbiIsInJlcXVpcmUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInNob3dSVkJ0biIsInR5cGUiLCJCdXR0b24iLCJzaG93SW50ZXJzaXRpYWxCdG4iLCJzdGFydCIsImFwcGlkIiwiYmFubmVySUQiLCJub2RlIiwib24iLCJzaG93UlYiLCJzaG93SW50ZXJzdGl0aWFsIiwibmJzZGsiLCJpbml0IiwibG9hZEJhbm5lciIsInNob3dCYW5uZXJDYWxsYmFjayIsImlzQmFubmVyUmVhZHkiLCJ1bnNjaGVkdWxlIiwic2hvd0Jhbm5lciIsImNvbnNvbGUiLCJsb2ciLCJzY2hlZHVsZSIsImJ1dHRvbiIsImlzSW50ZXJzdGl0aWFsUmVhZHkiLCJpc1Jld2FyZGVkVmlkZW9SZWFkeSIsInNob3dSZXdhcmRlZFZpZGVvIiwib25EZXN0cm95IiwiaGlkZUJhbm5lciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxJQUFJQSxXQUFXLEdBQUdDLE9BQU8sQ0FBQyxhQUFELENBQXpCOztBQUVBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFFUkMsSUFBQUEsU0FBUyxFQUFFO0FBQ1AsaUJBQVMsSUFERjtBQUVQQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGRixLQUZIO0FBT1JDLElBQUFBLGtCQUFrQixFQUFFO0FBQ2hCLGlCQUFTLElBRE87QUFFaEJGLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZPO0FBUFosR0FIUDtBQWdCTDtBQUVBO0FBRUFFLEVBQUFBLEtBcEJLLG1CQW9CSTtBQUNMO0FBQ0EsU0FBS0MsS0FBTCxHQUFjLGtDQUFkO0FBQ0EsU0FBS0MsUUFBTCxHQUFnQixLQUFoQixDQUhLLENBS0w7O0FBQ0EsU0FBS04sU0FBTCxDQUFlTyxJQUFmLENBQW9CQyxFQUFwQixDQUF1QixPQUF2QixFQUFnQyxLQUFLQyxNQUFyQyxFQUE2QyxJQUE3QztBQUNBLFNBQUtOLGtCQUFMLENBQXdCSSxJQUF4QixDQUE2QkMsRUFBN0IsQ0FBZ0MsT0FBaEMsRUFBeUMsS0FBS0UsZ0JBQTlDLEVBQWdFLElBQWhFLEVBUEssQ0FTTDs7QUFDQSxTQUFLQyxLQUFMLEdBQWEsSUFBSWpCLFdBQUosRUFBYjtBQUNBLFNBQUtpQixLQUFMLENBQVdDLElBQVgsQ0FBZ0IsS0FBS1AsS0FBckIsRUFYSyxDQWFMOztBQUNBLFNBQUtNLEtBQUwsQ0FBV0UsVUFBWCxDQUFzQixLQUFLUCxRQUEzQjs7QUFDQSxTQUFLUSxrQkFBTCxHQUEwQixZQUFVO0FBQ2hDLFVBQUcsS0FBS0gsS0FBTCxDQUFXSSxhQUFYLENBQXlCLEtBQUtULFFBQTlCLENBQUgsRUFBMkM7QUFDdkMsYUFBS1UsVUFBTCxDQUFnQixLQUFLRixrQkFBckI7QUFDQSxhQUFLSCxLQUFMLENBQVdNLFVBQVgsQ0FBc0IsS0FBS1gsUUFBM0I7QUFDSCxPQUhELE1BR0s7QUFDRFksUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksb0JBQVo7QUFDSDtBQUNKLEtBUEQ7O0FBUUEsU0FBS0MsUUFBTCxDQUFjLEtBQUtOLGtCQUFuQixFQUF1QyxHQUF2QztBQUVILEdBN0NJO0FBK0NMSixFQUFBQSxnQkFBZ0IsRUFBRSwwQkFBVVcsTUFBVixFQUFrQjtBQUNoQ0gsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksa0JBQVosRUFEZ0MsQ0FFaEM7O0FBQ0EsUUFBRyxLQUFLUixLQUFMLENBQVdXLG1CQUFYLEVBQUgsRUFBb0M7QUFDaEMsV0FBS1gsS0FBTCxDQUFXRCxnQkFBWDtBQUNILEtBRkQsTUFFSztBQUNEUSxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSwwQkFBWjtBQUNIO0FBQ0osR0F2REk7QUF5RExWLEVBQUFBLE1BQU0sRUFBRSxnQkFBVVksTUFBVixFQUFrQjtBQUN0QkgsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWixFQURzQixDQUV0Qjs7QUFDQSxRQUFHLEtBQUtSLEtBQUwsQ0FBV1ksb0JBQVgsRUFBSCxFQUFxQztBQUNqQyxXQUFLWixLQUFMLENBQVdhLGlCQUFYO0FBQ0gsS0FGRCxNQUVLO0FBQ0ROLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGdCQUFaO0FBQ0g7QUFDSixHQWpFSTtBQW1FTE0sRUFBQUEsU0FuRUssdUJBbUVNO0FBQ1AsU0FBS2QsS0FBTCxDQUFXZSxVQUFYLENBQXNCLEtBQUtwQixRQUEzQjtBQUNILEdBckVJLENBdUVMOztBQXZFSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcbi8vIExlYXJuIEF0dHJpYnV0ZTpcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxuXG52YXIgTkJNZWRpYXRpb24gPSByZXF1aXJlKCdOQk1lZGlhdGlvbicpO1xuXG5jYy5DbGFzcyh7XG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuXG4gICAgICAgIHNob3dSVkJ0bjoge1xuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcbiAgICAgICAgICAgIHR5cGU6IGNjLkJ1dHRvblxuICAgICAgICB9LFxuXG4gICAgICAgIHNob3dJbnRlcnNpdGlhbEJ0bjoge1xuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcbiAgICAgICAgICAgIHR5cGU6IGNjLkJ1dHRvblxuICAgICAgICB9LFxuICAgIH0sXG5cbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcblxuICAgIC8vIG9uTG9hZCAoKSB7fSxcblxuICAgIHN0YXJ0ICgpIHtcbiAgICAgICAgLy9zZXR1cCBpZCBoZXJlXG4gICAgICAgIHRoaXMuYXBwaWQgPSAgXCJrWERsS3ZPd0ZZZjBpblhCZDY1UHpvMHZwRjJ1dEJpbVwiXG4gICAgICAgIHRoaXMuYmFubmVySUQgPSBcIjI1OVwiO1xuXG4gICAgICAgIC8vc2V0dXAgYnV0dG9uIGNsaWNrIGV2ZW50XG4gICAgICAgIHRoaXMuc2hvd1JWQnRuLm5vZGUub24oJ2NsaWNrJywgdGhpcy5zaG93UlYsIHRoaXMpO1xuICAgICAgICB0aGlzLnNob3dJbnRlcnNpdGlhbEJ0bi5ub2RlLm9uKCdjbGljaycsIHRoaXMuc2hvd0ludGVyc3RpdGlhbCwgdGhpcyk7XG5cbiAgICAgICAgLy9pbml0IG1lZGlhdGlvbiBcbiAgICAgICAgdGhpcy5uYnNkayA9IG5ldyBOQk1lZGlhdGlvbigpO1xuICAgICAgICB0aGlzLm5ic2RrLmluaXQodGhpcy5hcHBpZCk7XG5cbiAgICAgICAgLy9sb2FkIGJhbm5lciBcbiAgICAgICAgdGhpcy5uYnNkay5sb2FkQmFubmVyKHRoaXMuYmFubmVySUQpO1xuICAgICAgICB0aGlzLnNob3dCYW5uZXJDYWxsYmFjayA9IGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICBpZih0aGlzLm5ic2RrLmlzQmFubmVyUmVhZHkodGhpcy5iYW5uZXJJRCkpe1xuICAgICAgICAgICAgICAgIHRoaXMudW5zY2hlZHVsZSh0aGlzLnNob3dCYW5uZXJDYWxsYmFjayk7XG4gICAgICAgICAgICAgICAgdGhpcy5uYnNkay5zaG93QmFubmVyKHRoaXMuYmFubmVySUQpO1xuICAgICAgICAgICAgfWVsc2V7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJiYW5uZXIgaXNuJ3QgcmVhZHlcIik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zY2hlZHVsZSh0aGlzLnNob3dCYW5uZXJDYWxsYmFjaywgMC41KTtcblxuICAgIH0sXG5cbiAgICBzaG93SW50ZXJzdGl0aWFsOiBmdW5jdGlvbiAoYnV0dG9uKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwic2hvd0ludGVyc3RpdGlhbFwiKTtcbiAgICAgICAgLy9sb2FkIGludGVyc3RpdGlhbFxuICAgICAgICBpZih0aGlzLm5ic2RrLmlzSW50ZXJzdGl0aWFsUmVhZHkoKSl7XG4gICAgICAgICAgICB0aGlzLm5ic2RrLnNob3dJbnRlcnN0aXRpYWwoKTtcbiAgICAgICAgfWVsc2V7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImludGVyc3RpdGlhbCBpc24ndCByZWFkeVwiKTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBzaG93UlY6IGZ1bmN0aW9uIChidXR0b24pIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJzaG93UlZcIik7XG4gICAgICAgIC8vbG9hZCByZXdhcmRlZCB2aWRlb1xuICAgICAgICBpZih0aGlzLm5ic2RrLmlzUmV3YXJkZWRWaWRlb1JlYWR5KCkpe1xuICAgICAgICAgICAgdGhpcy5uYnNkay5zaG93UmV3YXJkZWRWaWRlbygpO1xuICAgICAgICB9ZWxzZXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwicnYgaXNuJ3QgcmVhZHlcIik7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgb25EZXN0cm95KCl7XG4gICAgICAgIHRoaXMubmJzZGsuaGlkZUJhbm5lcih0aGlzLmJhbm5lcklEKTtcbiAgICB9LFxuXG4gICAgLy8gdXBkYXRlIChkdCkge30sXG59KTtcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/migration/use_v2.1-2.2.1_cc.Toggle_event.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e29d6nuXPlGpajUg5kPvwMH', 'use_v2.1-2.2.1_cc.Toggle_event');
// migration/use_v2.1-2.2.1_cc.Toggle_event.js

"use strict";

/*
 * This script is automatically generated by Cocos Creator and is only used for projects compatible with the v2.1.0 ～ 2.2.1 version.
 * You do not need to manually add this script in any other project.
 * If you don't use cc.Toggle in your project, you can delete this script directly.
 * If your project is hosted in VCS such as git, submit this script together.
 *
 * 此脚本由 Cocos Creator 自动生成，仅用于兼容 v2.1.0 ~ 2.2.1 版本的工程，
 * 你无需在任何其它项目中手动添加此脚本。
 * 如果你的项目中没用到 Toggle，可直接删除该脚本。
 * 如果你的项目有托管于 git 等版本库，请将此脚本一并上传。
 */
if (cc.Toggle) {
  // Whether to trigger 'toggle' and 'checkEvents' events when modifying 'toggle.isChecked' in the code
  // 在代码中修改 'toggle.isChecked' 时是否触发 'toggle' 与 'checkEvents' 事件
  cc.Toggle._triggerEventInScript_isChecked = true;
}

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9taWdyYXRpb24vdXNlX3YyLjEtMi4yLjFfY2MuVG9nZ2xlX2V2ZW50LmpzIl0sIm5hbWVzIjpbImNjIiwiVG9nZ2xlIiwiX3RyaWdnZXJFdmVudEluU2NyaXB0X2lzQ2hlY2tlZCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTs7Ozs7Ozs7Ozs7QUFZQSxJQUFJQSxFQUFFLENBQUNDLE1BQVAsRUFBZTtBQUNYO0FBQ0E7QUFDQUQsRUFBQUEsRUFBRSxDQUFDQyxNQUFILENBQVVDLCtCQUFWLEdBQTRDLElBQTVDO0FBQ0giLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBUaGlzIHNjcmlwdCBpcyBhdXRvbWF0aWNhbGx5IGdlbmVyYXRlZCBieSBDb2NvcyBDcmVhdG9yIGFuZCBpcyBvbmx5IHVzZWQgZm9yIHByb2plY3RzIGNvbXBhdGlibGUgd2l0aCB0aGUgdjIuMS4wIO+9niAyLjIuMSB2ZXJzaW9uLlxuICogWW91IGRvIG5vdCBuZWVkIHRvIG1hbnVhbGx5IGFkZCB0aGlzIHNjcmlwdCBpbiBhbnkgb3RoZXIgcHJvamVjdC5cbiAqIElmIHlvdSBkb24ndCB1c2UgY2MuVG9nZ2xlIGluIHlvdXIgcHJvamVjdCwgeW91IGNhbiBkZWxldGUgdGhpcyBzY3JpcHQgZGlyZWN0bHkuXG4gKiBJZiB5b3VyIHByb2plY3QgaXMgaG9zdGVkIGluIFZDUyBzdWNoIGFzIGdpdCwgc3VibWl0IHRoaXMgc2NyaXB0IHRvZ2V0aGVyLlxuICpcbiAqIOatpOiEmuacrOeUsSBDb2NvcyBDcmVhdG9yIOiHquWKqOeUn+aIkO+8jOS7heeUqOS6juWFvOWuuSB2Mi4xLjAgfiAyLjIuMSDniYjmnKznmoTlt6XnqIvvvIxcbiAqIOS9oOaXoOmcgOWcqOS7u+S9leWFtuWug+mhueebruS4reaJi+WKqOa3u+WKoOatpOiEmuacrOOAglxuICog5aaC5p6c5L2g55qE6aG555uu5Lit5rKh55So5YiwIFRvZ2dsZe+8jOWPr+ebtOaOpeWIoOmZpOivpeiEmuacrOOAglxuICog5aaC5p6c5L2g55qE6aG555uu5pyJ5omY566h5LqOIGdpdCDnrYnniYjmnKzlupPvvIzor7flsIbmraTohJrmnKzkuIDlubbkuIrkvKDjgIJcbiAqL1xuXG5pZiAoY2MuVG9nZ2xlKSB7XG4gICAgLy8gV2hldGhlciB0byB0cmlnZ2VyICd0b2dnbGUnIGFuZCAnY2hlY2tFdmVudHMnIGV2ZW50cyB3aGVuIG1vZGlmeWluZyAndG9nZ2xlLmlzQ2hlY2tlZCcgaW4gdGhlIGNvZGVcbiAgICAvLyDlnKjku6PnoIHkuK3kv67mlLkgJ3RvZ2dsZS5pc0NoZWNrZWQnIOaXtuaYr+WQpuinpuWPkSAndG9nZ2xlJyDkuI4gJ2NoZWNrRXZlbnRzJyDkuovku7ZcbiAgICBjYy5Ub2dnbGUuX3RyaWdnZXJFdmVudEluU2NyaXB0X2lzQ2hlY2tlZCA9IHRydWU7XG59XG4iXX0=
//------QC-SOURCE-SPLIT------
