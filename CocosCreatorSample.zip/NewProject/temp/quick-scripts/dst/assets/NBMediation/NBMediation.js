
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/NBMediation/NBMediation.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '41aaa10R/tFqbtaiEZQaOxN', 'NBMediation');
// NBMediation/NBMediation.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var NBMediation = cc.Class({
  "extends": cc.Component,
  properties: {// foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  init: function init(appid) {
    console.log("appid:" + appid);
    jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "initNBMediation", "(Ljava/lang/String;)V", appid);
  },
  isRewardedVideoReady: function isRewardedVideoReady() {
    return jsb.reflection.callStaticMethod("com/nbmediation/sdk/api/unity/NmSdk", "isRewardedVideoReady", "()Z");
  },
  showRewardedVideo: function showRewardedVideo() {
    jsb.reflection.callStaticMethod("com/nbmediation/sdk/api/unity/NmSdk", "showRewardedVideo", "()V");
  },
  isInterstitialReady: function isInterstitialReady() {
    return jsb.reflection.callStaticMethod("com/nbmediation/sdk/api/unity/NmSdk", "isInterstitialReady", "()Z");
  },
  showInterstitial: function showInterstitial() {
    jsb.reflection.callStaticMethod("com/nbmediation/sdk/api/unity/NmSdk", "showInterstitial", "()V");
  },
  loadBanner: function loadBanner(slotid) {
    jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "loadBanner", "(Ljava/lang/String;)V", slotid);
  },
  showBanner: function showBanner(slotid) {
    jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "showBanner", "(Ljava/lang/String;)V", slotid);
  },
  hideBanner: function hideBanner(slotid) {
    jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "hideBanner", "(Ljava/lang/String;)V", slotid);
  },
  isBannerReady: function isBannerReady(slotid) {
    return jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "isBannerReady", "(Ljava/lang/String;)Z", slotid);
  } // update (dt) {},

});
module.exports = NBMediation;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9OQk1lZGlhdGlvbi9OQk1lZGlhdGlvbi5qcyJdLCJuYW1lcyI6WyJOQk1lZGlhdGlvbiIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwic3RhcnQiLCJpbml0IiwiYXBwaWQiLCJjb25zb2xlIiwibG9nIiwianNiIiwicmVmbGVjdGlvbiIsImNhbGxTdGF0aWNNZXRob2QiLCJpc1Jld2FyZGVkVmlkZW9SZWFkeSIsInNob3dSZXdhcmRlZFZpZGVvIiwiaXNJbnRlcnN0aXRpYWxSZWFkeSIsInNob3dJbnRlcnN0aXRpYWwiLCJsb2FkQmFubmVyIiwic2xvdGlkIiwic2hvd0Jhbm5lciIsImhpZGVCYW5uZXIiLCJpc0Jhbm5lclJlYWR5IiwibW9kdWxlIiwiZXhwb3J0cyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxJQUFJQSxXQUFXLEdBQUdDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ3ZCLGFBQVNELEVBQUUsQ0FBQ0UsU0FEVztBQUd2QkMsRUFBQUEsVUFBVSxFQUFFLENBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBZlEsR0FIVztBQXFCdkI7QUFFQTtBQUVBQyxFQUFBQSxLQXpCdUIsbUJBeUJkLENBR1IsQ0E1QnNCO0FBOEJ2QkMsRUFBQUEsSUE5QnVCLGdCQThCakJDLEtBOUJpQixFQThCVjtBQUNUQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxXQUFXRixLQUF2QjtBQUNBRyxJQUFBQSxHQUFHLENBQUNDLFVBQUosQ0FBZUMsZ0JBQWYsQ0FBZ0MscUNBQWhDLEVBQXVFLGlCQUF2RSxFQUEwRix1QkFBMUYsRUFBbUhMLEtBQW5IO0FBQ0gsR0FqQ3NCO0FBbUN2Qk0sRUFBQUEsb0JBbkN1QixrQ0FtQ0E7QUFDbkIsV0FBT0gsR0FBRyxDQUFDQyxVQUFKLENBQWVDLGdCQUFmLENBQWdDLHFDQUFoQyxFQUF1RSxzQkFBdkUsRUFBK0YsS0FBL0YsQ0FBUDtBQUNILEdBckNzQjtBQXVDdkJFLEVBQUFBLGlCQXZDdUIsK0JBdUNIO0FBQ2hCSixJQUFBQSxHQUFHLENBQUNDLFVBQUosQ0FBZUMsZ0JBQWYsQ0FBZ0MscUNBQWhDLEVBQXVFLG1CQUF2RSxFQUE0RixLQUE1RjtBQUNILEdBekNzQjtBQTJDdkJHLEVBQUFBLG1CQTNDdUIsaUNBMkNEO0FBQ2xCLFdBQU9MLEdBQUcsQ0FBQ0MsVUFBSixDQUFlQyxnQkFBZixDQUFnQyxxQ0FBaEMsRUFBdUUscUJBQXZFLEVBQThGLEtBQTlGLENBQVA7QUFDSCxHQTdDc0I7QUErQ3ZCSSxFQUFBQSxnQkEvQ3VCLDhCQStDSjtBQUNmTixJQUFBQSxHQUFHLENBQUNDLFVBQUosQ0FBZUMsZ0JBQWYsQ0FBZ0MscUNBQWhDLEVBQXVFLGtCQUF2RSxFQUEyRixLQUEzRjtBQUNILEdBakRzQjtBQW1EdkJLLEVBQUFBLFVBbkR1QixzQkFtRFpDLE1BbkRZLEVBbURMO0FBQ2RSLElBQUFBLEdBQUcsQ0FBQ0MsVUFBSixDQUFlQyxnQkFBZixDQUFnQyxxQ0FBaEMsRUFBdUUsWUFBdkUsRUFBcUYsdUJBQXJGLEVBQThHTSxNQUE5RztBQUNILEdBckRzQjtBQXVEdkJDLEVBQUFBLFVBdkR1QixzQkF1RFpELE1BdkRZLEVBdURMO0FBQ2RSLElBQUFBLEdBQUcsQ0FBQ0MsVUFBSixDQUFlQyxnQkFBZixDQUFnQyxxQ0FBaEMsRUFBdUUsWUFBdkUsRUFBcUYsdUJBQXJGLEVBQThHTSxNQUE5RztBQUNILEdBekRzQjtBQTJEdkJFLEVBQUFBLFVBM0R1QixzQkEyRFpGLE1BM0RZLEVBMkRMO0FBQ2RSLElBQUFBLEdBQUcsQ0FBQ0MsVUFBSixDQUFlQyxnQkFBZixDQUFnQyxxQ0FBaEMsRUFBdUUsWUFBdkUsRUFBcUYsdUJBQXJGLEVBQThHTSxNQUE5RztBQUNILEdBN0RzQjtBQStEdkJHLEVBQUFBLGFBL0R1Qix5QkErRFRILE1BL0RTLEVBK0RGO0FBQ2pCLFdBQU9SLEdBQUcsQ0FBQ0MsVUFBSixDQUFlQyxnQkFBZixDQUFnQyxxQ0FBaEMsRUFBdUUsZUFBdkUsRUFBd0YsdUJBQXhGLEVBQWlITSxNQUFqSCxDQUFQO0FBQ0gsR0FqRXNCLENBbUV2Qjs7QUFuRXVCLENBQVQsQ0FBbEI7QUFxRUFJLE1BQU0sQ0FBQ0MsT0FBUCxHQUFpQnZCLFdBQWpCIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcbi8vIExlYXJuIEF0dHJpYnV0ZTpcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxuXG52YXIgTkJNZWRpYXRpb24gPSBjYy5DbGFzcyh7XG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgIC8vIEFUVFJJQlVURVM6XG4gICAgICAgIC8vICAgICBkZWZhdWx0OiBudWxsLCAgICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgIHR5cGU6IGNjLlNwcml0ZUZyYW1lLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICAgc2VyaWFsaXphYmxlOiB0cnVlLCAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gYmFyOiB7XG4gICAgICAgIC8vICAgICBnZXQgKCkge1xuICAgICAgICAvLyAgICAgICAgIHJldHVybiB0aGlzLl9iYXI7XG4gICAgICAgIC8vICAgICB9LFxuICAgICAgICAvLyAgICAgc2V0ICh2YWx1ZSkge1xuICAgICAgICAvLyAgICAgICAgIHRoaXMuX2JhciA9IHZhbHVlO1xuICAgICAgICAvLyAgICAgfVxuICAgICAgICAvLyB9LFxuICAgIH0sXG5cbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcblxuICAgIC8vIG9uTG9hZCAoKSB7fSxcblxuICAgIHN0YXJ0ICgpIHtcblxuXG4gICAgfSxcblxuICAgIGluaXQgKGFwcGlkKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiYXBwaWQ6XCIgKyBhcHBpZCk7XG4gICAgICAgIGpzYi5yZWZsZWN0aW9uLmNhbGxTdGF0aWNNZXRob2QoXCJvcmcvY29jb3MyZHgvamF2YXNjcmlwdC9BcHBBY3Rpdml0eVwiLCBcImluaXROQk1lZGlhdGlvblwiLCBcIihMamF2YS9sYW5nL1N0cmluZzspVlwiLCBhcHBpZCk7XG4gICAgfSxcblxuICAgIGlzUmV3YXJkZWRWaWRlb1JlYWR5KCkge1xuICAgICAgICByZXR1cm4ganNiLnJlZmxlY3Rpb24uY2FsbFN0YXRpY01ldGhvZChcImNvbS9uYm1lZGlhdGlvbi9zZGsvYXBpL3VuaXR5L05tU2RrXCIsIFwiaXNSZXdhcmRlZFZpZGVvUmVhZHlcIiwgXCIoKVpcIik7XG4gICAgfSxcblxuICAgIHNob3dSZXdhcmRlZFZpZGVvKCkge1xuICAgICAgICBqc2IucmVmbGVjdGlvbi5jYWxsU3RhdGljTWV0aG9kKFwiY29tL25ibWVkaWF0aW9uL3Nkay9hcGkvdW5pdHkvTm1TZGtcIiwgXCJzaG93UmV3YXJkZWRWaWRlb1wiLCBcIigpVlwiKTtcbiAgICB9LFxuXG4gICAgaXNJbnRlcnN0aXRpYWxSZWFkeSgpIHtcbiAgICAgICAgcmV0dXJuIGpzYi5yZWZsZWN0aW9uLmNhbGxTdGF0aWNNZXRob2QoXCJjb20vbmJtZWRpYXRpb24vc2RrL2FwaS91bml0eS9ObVNka1wiLCBcImlzSW50ZXJzdGl0aWFsUmVhZHlcIiwgXCIoKVpcIik7XG4gICAgfSxcblxuICAgIHNob3dJbnRlcnN0aXRpYWwoKSB7XG4gICAgICAgIGpzYi5yZWZsZWN0aW9uLmNhbGxTdGF0aWNNZXRob2QoXCJjb20vbmJtZWRpYXRpb24vc2RrL2FwaS91bml0eS9ObVNka1wiLCBcInNob3dJbnRlcnN0aXRpYWxcIiwgXCIoKVZcIik7XG4gICAgfSxcblxuICAgIGxvYWRCYW5uZXIoc2xvdGlkKXtcbiAgICAgICAganNiLnJlZmxlY3Rpb24uY2FsbFN0YXRpY01ldGhvZChcIm9yZy9jb2NvczJkeC9qYXZhc2NyaXB0L0FwcEFjdGl2aXR5XCIsIFwibG9hZEJhbm5lclwiLCBcIihMamF2YS9sYW5nL1N0cmluZzspVlwiLCBzbG90aWQpO1xuICAgIH0sXG5cbiAgICBzaG93QmFubmVyKHNsb3RpZCl7XG4gICAgICAgIGpzYi5yZWZsZWN0aW9uLmNhbGxTdGF0aWNNZXRob2QoXCJvcmcvY29jb3MyZHgvamF2YXNjcmlwdC9BcHBBY3Rpdml0eVwiLCBcInNob3dCYW5uZXJcIiwgXCIoTGphdmEvbGFuZy9TdHJpbmc7KVZcIiwgc2xvdGlkKTtcbiAgICB9LFxuXG4gICAgaGlkZUJhbm5lcihzbG90aWQpe1xuICAgICAgICBqc2IucmVmbGVjdGlvbi5jYWxsU3RhdGljTWV0aG9kKFwib3JnL2NvY29zMmR4L2phdmFzY3JpcHQvQXBwQWN0aXZpdHlcIiwgXCJoaWRlQmFubmVyXCIsIFwiKExqYXZhL2xhbmcvU3RyaW5nOylWXCIsIHNsb3RpZCk7XG4gICAgfSxcblxuICAgIGlzQmFubmVyUmVhZHkoc2xvdGlkKXtcbiAgICAgICAgcmV0dXJuIGpzYi5yZWZsZWN0aW9uLmNhbGxTdGF0aWNNZXRob2QoXCJvcmcvY29jb3MyZHgvamF2YXNjcmlwdC9BcHBBY3Rpdml0eVwiLCBcImlzQmFubmVyUmVhZHlcIiwgXCIoTGphdmEvbGFuZy9TdHJpbmc7KVpcIiwgc2xvdGlkKTtcbiAgICB9LFxuXG4gICAgLy8gdXBkYXRlIChkdCkge30sXG59KTtcbm1vZHVsZS5leHBvcnRzID0gTkJNZWRpYXRpb247Il19